# -*- coding: utf-8 -*-

default_app_config = "phone_verify.apps.PhoneVerificationConfig"
