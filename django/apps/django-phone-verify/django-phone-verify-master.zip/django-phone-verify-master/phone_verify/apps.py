from django.apps import AppConfig


class PhoneVerificationConfig(AppConfig):
    name = "phone_verify"
    verbose_name = "Phone Verification"
